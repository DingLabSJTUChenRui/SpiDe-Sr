# coding: utf-8

from __future__ import division
import os
import time
import glob
import datetime
import argparse
import numpy as np

import cv2
from PIL import Image
import torch
import torch.optim as optim
from torch.optim import lr_scheduler
from torchvision import transforms
from torch.utils.data import DataLoader
from torch.utils.data import Dataset

from arch_unet import UNet
import imageio
import fnmatch

parser = argparse.ArgumentParser()
# parser.add_argument("--test_dataset", type=str, default="./my_testing_dataset/withNoiseCell(L)_Aligned_IMC")
parser.add_argument("--test_dataset", type=str, default="E:/SpiDe-Sr/testImages")
parser.add_argument('--saved_model', type=str, default='E:/SpiDe-Sr/De-Net/pretrained_model/test1w_epoch_500.pth')
parser.add_argument('--gpu_devices', default='0', type=str)
parser.add_argument('--parallel', default=False)
parser.add_argument('--n_feature', type=int, default=48)
parser.add_argument('--n_channel', type=int, default=3)
parser.add_argument('--repeat_times', type=int, default=3)

opt, _ = parser.parse_known_args()
systime = datetime.datetime.now().strftime('%Y-%m-%d-%H-%M')
operation_seed_counter = 0
os.environ['CUDA_VISIBLE_DEVICES'] = opt.gpu_devices

# print(torch.cuda.device_count())
# print(torch.cuda.is_available())

# def load_test_dataset(dataset_dir):
#     fns = glob.glob(os.path.join(dataset_dir, "*"), recursive=False)
#     fns.sort()
#     images = []
#     for fn in fns:
#         if fnmatch.fnmatch(fn, '*.tiff'):
#             # im = imageio.imread(fn)
#             im = Image.open(fn)
#             im = np.array(im, dtype=np.float32)
#             images.append(im)
#     return images


def ssim(prediction, target):
    C1 = (0.01 * 65535.0)**2
    C2 = (0.03 * 65535.0)**2
    img1 = prediction.astype(np.float64)
    img2 = target.astype(np.float64)
    kernel = cv2.getGaussianKernel(11, 1.5)
    window = np.outer(kernel, kernel.transpose())
    mu1 = cv2.filter2D(img1, -1, window)[5:-5, 5:-5]  # valid
    mu2 = cv2.filter2D(img2, -1, window)[5:-5, 5:-5]
    mu1_sq = mu1**2
    mu2_sq = mu2**2
    mu1_mu2 = mu1 * mu2
    sigma1_sq = cv2.filter2D(img1**2, -1, window)[5:-5, 5:-5] - mu1_sq
    sigma2_sq = cv2.filter2D(img2**2, -1, window)[5:-5, 5:-5] - mu2_sq
    sigma12 = cv2.filter2D(img1 * img2, -1, window)[5:-5, 5:-5] - mu1_mu2
    ssim_map = ((2 * mu1_mu2 + C1) *
                (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) *
                                       (sigma1_sq + sigma2_sq + C2))
    return ssim_map.mean()


def calculate_ssim(target, ref):
    '''
    calculate SSIM
    the same outputs as MATLAB's
    img1, img2: [0, 65535]
    '''
    img1 = np.array(target, dtype=np.float64)
    img2 = np.array(ref, dtype=np.float64)
    if not img1.shape == img2.shape:
        raise ValueError('Input images must have the same dimensions.')
    if img1.ndim == 2:
        return ssim(img1, img2)
    elif img1.ndim == 3:
        if img1.shape[2] == 3:
            ssims = []
            for i in range(3):
                ssims.append(ssim(img1[:, :, i], img2[:, :, i]))
            return np.array(ssims).mean()
        elif img1.shape[2] == 1:
            return ssim(np.squeeze(img1), np.squeeze(img2))
    else:
        raise ValueError('Wrong input image dimensions.')


def calculate_psnr(target, ref):
    img1 = np.array(target, dtype=np.float32)
    img2 = np.array(ref, dtype=np.float32)
    diff = img1 - img2
    psnr = 10.0 * np.log10(65535.0 * 65535.0 / np.mean(np.square(diff)))
    return psnr


image_names = glob.glob(os.path.join(opt.test_dataset, "*"), recursive=False)
image_names.sort()

results = os.path.join(opt.test_dataset, "results")
os.makedirs(results, exist_ok=True)

# network
network = UNet(in_nc=opt.n_channel,
               out_nc=opt.n_channel,
               n_feature=opt.n_feature)

if opt.parallel:
    network = torch.nn.DataParallel(network)
network = network.cuda()
checkpoint = torch.load(opt.saved_model, map_location='cpu')
network.load_state_dict(checkpoint)

network.eval()
psnr_results = []
ssim_results = []
for i in range(opt.repeat_times):
    for fn in image_names:
        if fnmatch.fnmatch(fn, '*.tiff'):
            im = imageio.imread(fn)
            # im = Image.open(fn)
            im = np.array(im, dtype=np.float32)

            origin255 = im.copy()
            origin255 = origin255.astype(np.uint16)

            im = im / 65535.0

            H = im.shape[0]
            W = im.shape[1]
            test_size = (max(H, W) + 31) // 32 * 32
            im = np.pad(
                im,
                [[0, test_size - H], [0, test_size - W], [0, 0]],
                'reflect'
            )
            transformer = transforms.Compose([transforms.ToTensor()])
            im = transformer(im)
            im = torch.unsqueeze(im, 0)
            im = im.cuda()
            with torch.no_grad():
                prediction = network(im)
                prediction = prediction[:, :, :H, :W]
            prediction = prediction.permute(0, 2, 3, 1)
            prediction = prediction.cpu().data.clamp(0, 1).numpy()
            prediction = prediction.squeeze()


            pred255 = np.clip(prediction * 65535.0 + 0.5, 0,
                              65535).astype(np.uint16)

            # calculate psnr
            cur_psnr = calculate_psnr(origin255.astype(np.float32),
                                      pred255.astype(np.float32))
            psnr_results.append(cur_psnr)
            cur_ssim = calculate_ssim(origin255.astype(np.float32),
                                      pred255.astype(np.float32))
            ssim_results.append(cur_ssim)

            img_basename = os.path.basename(fn)
            save_path = os.path.join(results, img_basename)

            imageio.imsave(save_path, pred255)
            # Image.fromarray(pred255).save(save_path)
            # Image.fromarray(pred255).convert('RGB').save(save_path)

psnr_result = np.array(psnr_results)
avg_psnr = np.mean(psnr_results)
avg_ssim = np.mean(ssim_results)
log_path = os.path.join(results, "log_test_results.csv")
with open(log_path, "a") as f:
    f.writelines("avg_psnr,avg_ssim\n")
    f.writelines("{},{}\n".format(avg_psnr, avg_ssim))
