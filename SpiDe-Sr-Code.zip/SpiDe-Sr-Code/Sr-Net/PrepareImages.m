clc
clear all

%% 
img_path = 'E:\SpiDe-Sr\testImages\results\';
img_List = dir(fullfile(img_path,'*.tiff'));

%%
N=length(img_List);

for i=1:N    

    img_name = img_List(i).name;
    img =  imread(strcat(img_path,img_name));
    img =img(:,:,1:3);
    img=im2uint8(img);

    name=img_name(1:end-5);
    Pic_newname = strcat('E:\SpiDe-Sr\Sr-Net\clean_testImages\',name,'.png');
    imwrite(img,Pic_newname);
end


