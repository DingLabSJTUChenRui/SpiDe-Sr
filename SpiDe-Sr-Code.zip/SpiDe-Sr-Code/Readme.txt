This file contains three sections:
1. denoising network
2.Super-resolution network
3. images used for testing

How to run the code:
Step 1: Change the address of the pretrained_model(test1w_epoch_500.pth) in the SpiDe-Sr-Code\De-Net\reference.py;
Step 2: Run reference.py to get the result;
Step 3: Run SpiDe-Sr-Code\Sr-Net\PrepareImages.m to adjust the image format;
Step 4: Open SpiDe-Sr-Code\Sr-Net\codes\test_Sr.py and change the correct addresses of the three .yml files in SpiDe-Sr-Code\Sr-Net\codes\options\test\;
Step 5: Run SpiDe-Sr-Code\Sr-Net\codes\test_Sr.py.